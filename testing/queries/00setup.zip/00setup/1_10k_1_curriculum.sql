INSERT INTO public.curriculum (curriculum_year,curriculum_name,created) VALUES
	 ('2002','Sims-Jones','2024-12-30 00:14:21.810899'),
	 ('2004','Green-Mann','2024-12-30 00:14:21.810899'),
	 ('2010','Wallace-Ingram','2024-12-30 00:14:21.810899'),
	 ('2011','James-Young','2024-12-30 00:14:21.810899'),
	 ('2013','Brown, Thompson and Parker','2024-12-30 00:14:21.810899');
	 ('2014','Davis PLC','2024-12-30 00:14:21.810899'),
	 ('2017','Bonilla, Monroe and Gomez','2024-12-30 00:14:21.810899'),
	 ('2018','Torres, Cooley and Oneill','2024-12-30 00:14:21.810899'),
	 ('2019','Deleon-Vaughn','2024-12-30 00:14:21.810899'),
	 ('2023','Smith-Williams','2024-12-30 00:14:21.810899');
