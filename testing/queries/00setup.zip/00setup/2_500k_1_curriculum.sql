INSERT INTO public.curriculum (curriculum_year,curriculum_name,created) VALUES
	 ('1991','Schultz, Collins and Taylor','2024-12-28 17:18:30.650068'),
	 ('2000','Smith Inc','2024-12-28 17:45:32.264417'),
	 ('2003','Golden-Nguyen','2024-12-28 17:31:19.342415'),
	 ('2005','Richard-Wright','2024-12-28 17:18:30.650068'),
	 ('2006','Robinson, Whitaker and Adkins','2024-12-28 17:31:19.342415'),
	 ('2007','Merritt-Hansen','2024-12-28 17:23:10.958863'),
	 ('2008','Powell Ltd','2024-12-28 17:23:10.958863'),
	 ('2009','Sweeney LLC','2024-12-28 17:23:10.958863'),
	 ('2015','Cummings, Cook and Rodriguez','2024-12-28 17:33:02.274666'),
	 ('2021','Walsh-Cummings','2024-12-28 17:18:50.729602');
INSERT INTO public.curriculum (curriculum_year,curriculum_name,created) VALUES
	 ('1993','Wells, Bennett and Camacho','2024-12-28 17:20:33.005292'),
	 ('1994','Bell Ltd','2024-12-28 17:28:12.002457'),
	 ('1995','Dunn, Jimenez and Bradley','2024-12-28 17:28:12.002457'),
	 ('1996','Anderson Ltd','2024-12-28 17:19:52.040125'),
	 ('1997','Lopez, Elliott and Coleman','2024-12-28 17:19:52.040125'),
	 ('1998','James, Arias and Morgan','2024-12-28 17:26:48.123372'),
	 ('1999','Lindsey-Ferrell','2024-12-28 17:47:59.503883'),
	 ('2022','Brooks-Vasquez','2024-12-28 17:18:50.729602'),
	 ('2024','Keller, Mitchell and Gilmore','2024-12-28 17:34:52.088357'),
	 ('2025','Miller-Turner','2024-12-28 17:26:48.123372');
INSERT INTO public.curriculum (curriculum_year,curriculum_name,created) VALUES
	 ('2001','Cherry-Floyd','2024-12-28 17:38:48.402068');
